package com.datkthor.streamming;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StreammingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
