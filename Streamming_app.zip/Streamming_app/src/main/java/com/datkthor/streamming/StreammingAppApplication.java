package com.datkthor.streamming;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StreammingAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(StreammingAppApplication.class, args);
	}

}
